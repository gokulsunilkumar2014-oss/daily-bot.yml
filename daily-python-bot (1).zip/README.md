# Daily Python Bot

Runs every day at 8:00 AM IST using GitHub Actions.

## Setup

1. Create a GitHub repository.
2. Upload all files.
3. Push to GitHub.
4. Enable GitHub Actions.

The workflow runs automatically at 08:00 IST (02:30 UTC).
